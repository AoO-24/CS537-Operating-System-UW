# XV6 Memory Management

**Name:** Wenpei Shao
**CS Login:** wenpei
**Wisc ID:** 9083215211
**Email:** wshao33@wisc.edu

**Partner** Weitao Su
**CS Login:** weitao
**Wisc ID:** 9083281262
**Email:** wsu43@wisc.edu

## Implementation Status:

All features implemented and pass all test.

## Files Modified:
proc.c proc.h usys.s syscall.c syscall.h sysproc.c trap.c Makefile defs.h

## PS
