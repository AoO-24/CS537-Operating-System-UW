Name: Wenpei Shao
cs login: wenpei
wisc ID: 9083215211
email: wshao33@wisc.edu
Status: all implementations of three class have been done, and have passed all test cases.
